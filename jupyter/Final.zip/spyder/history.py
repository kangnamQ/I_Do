# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

## ---(Sat Nov 28 05:03:24 2020)---
runfile('C:/Users/kayal/.spyder-py3/temp.py', wdir='C:/Users/kayal/.spyder-py3')
runfile('C:/Users/kayal/.spyder-py3/GTA5_chat_server.py', wdir='C:/Users/kayal/.spyder-py3')

## ---(Sat Nov 28 07:52:09 2020)---
runfile('C:/Users/kayal/.spyder-py3/GTA5_chat_server.py', wdir='C:/Users/kayal/.spyder-py3')
runfile('C:/Users/kayal/.spyder-py3/GTA5.py', wdir='C:/Users/kayal/.spyder-py3')

## ---(Sat Nov 28 14:53:51 2020)---
runfile('C:/Users/kayal/.spyder-py3/untitled0.py', wdir='C:/Users/kayal/.spyder-py3')